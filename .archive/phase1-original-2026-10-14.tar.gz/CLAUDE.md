# Claude Code & Anthropic Agent Configuration

This repository enforces the **Universal Clean Native Agent Specification (UCNA-Spec)**.

### Immediate Invariants for Claude Agents:
1. **Source of Truth**: Always read and adhere to [AGENTS.md](file:///Users/sinitygs/Projects23/AGENTS.md) and all rules in [.agents/rules/](file:///Users/sinitygs/Projects23/.agents/rules/).
2. **Native First**: Leverage runtime standard libraries (Node.js, Python stdlib, Go standard library, Rust std) before suggesting or importing external packages.
3. **No Incomplete Code**: Never write `// TODO`, `pass`, `...`, or placeholder code in solutions. Always provide full, compilable, and tested implementations.
4. **Verification**: Confirm file paths, API contracts, and command flags before invoking bash or modifying files.
