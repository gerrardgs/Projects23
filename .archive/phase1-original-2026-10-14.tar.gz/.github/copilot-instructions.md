# GitHub Copilot Custom Instructions

## Universal Clean Native Agent Specification (UCNA-Spec)

When generating code, suggestions, or refactoring in this repository:
1. Always write complete, production-grade implementations. Never leave `// TODO`, `...`, or placeholder code.
2. Maximize standard library features first (Native-First) before adding third-party packages.
3. Enforce strict static typing without shortcuts or `any`.
4. Ensure all error conditions are explicitly handled and validated at system boundaries.
5. Adhere to the core rules documented in `AGENTS.md` and `.agents/rules/`.
