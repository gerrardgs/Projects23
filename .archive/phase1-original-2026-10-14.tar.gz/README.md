# Universal Clean Native Agent Specification (UCNA-Spec)

> **Free, Open, Universal AI Agent Documentation, Rules & Skills Suite for Clean, Native, and Zero-Hallucination Coding.**
> Engineered for all AI models (Gemini, Claude, GPT, DeepSeek, Llama, Qwen) and all agentic platforms (Google Antigravity, Anthropic Claude Code, Cursor, Windsurf, Cline, Aider, GitHub Copilot).

---

## 1. Executive Summary & Philosophy

The **Universal Clean Native Agent Specification (UCNA-Spec)** establishes a rigorous, production-grade framework designed to elevate AI agent coding from simplistic, hallucination-prone script generation to the caliber of senior/principal systems architects writing native software from scratch.

### Core Pillars:
1. **Native-First, Zero-Bloat**: Leverage standard runtime libraries (Node.js, Python stdlib, Go standard library, Rust std) before importing external dependencies. Eliminate dependencies that duplicate platform capabilities.
2. **Absolute Implementation Completeness**: Eradicate "lazy agent syndrome". No `TODO` comments, no ellipsis (`...`), no partial stubs. Every implementation is complete, compilable, and production-ready.
3. **Deterministic Anti-Hallucination Protocol**: Enforce a 5-step cognitive audit loop that verifies package existence, validates API signatures against local types/docs, checks deprecations, and eliminates imaginary flags.
4. **Clean Code & Type Safety Invariants**: Strict compiler passes, zero `any`, algebraic data types (discriminated unions), pure functional domain cores isolated from side-effectful I/O shells, and cognitive cyclomatic complexity $\le 10$.
5. **Universal Portability**: A unified architecture with drop-in adapters for all major agent environments.

---

## 2. Directory Architecture & Harness Compatibility

```
Projects23/
├── AGENTS.md                   # Universal open standard rules (Antigravity, Cursor, Windsurf, Claude Code, Cline, Aider)
├── GEMINI.md                   # Google Antigravity & Gemini CLI configuration
├── CLAUDE.md                   # Anthropic Claude Code configuration
├── .cursorrules                # Cursor IDE configuration
├── .windsurfrules              # Windsurf IDE configuration
├── .github/
│   └── copilot-instructions.md # GitHub Copilot configuration
├── .agents/
│   ├── rules/                  # Comprehensive, modular rulebooks
│   │   ├── 00-index.md
│   │   ├── 01-core-philosophy.md
│   │   ├── 02-clean-code-invariants.md
│   │   ├── 03-anti-hallucination-verification.md
│   │   ├── 04-native-standard-first.md
│   │   └── 05-defensive-error-handling.md
│   └── skills/                 # Portable autonomous runbooks
│       ├── native-from-scratch/
│       │   └── SKILL.md
│       └── rigorous-code-audit/
│           └── SKILL.md
└── skills/                     # Root mirror for cross-tool discovery
    ├── native-from-scratch/
    └── rigorous-code-audit/
```

---

## 3. How to Use with Any AI Model or Tool

### Scenario A: Google Antigravity
The IDE automatically discovers customizations in `.agents/rules/`, `.agents/skills/`, and `GEMINI.md`. All rules and skills are progressively loaded and enforced natively.

### Scenario B: Anthropic Claude Code
Claude Code automatically parses `CLAUDE.md` and `AGENTS.md` in the current working directory, adopting the rules and referencing skills.

### Scenario C: Cursor & Windsurf IDEs
Both IDEs read `.cursorrules`, `.windsurfrules`, and `AGENTS.md` at project root, ensuring that inline generation and chat agents follow the exact same standards.

### Scenario D: General LLM Prompts (ChatGPT, DeepSeek, Claude Web, Gemini Web)
To use this with any web-based LLM, paste the contents of [AGENTS.md](file:///Users/sinitygs/Projects23/AGENTS.md) as a system prompt or preamble.

---

## 4. Phase 1 Delivery Overview

- [x] Universal Root Directive Hub (`AGENTS.md`, `GEMINI.md`, `CLAUDE.md`, `.cursorrules`, `.windsurfrules`, `.github/copilot-instructions.md`)
- [x] Rule R-01: Core Philosophy & Native Architectural Axioms
- [x] Rule R-02: Clean Code Invariants & Quality Standards
- [x] Rule R-03: Anti-Hallucination Protocol & Verification Discipline
- [x] Rule R-04: Native-Standard-First Paradigm & Dependency Elimination
- [x] Rule R-05: Defensive Error Handling & Invariant Enforcement
- [x] Skill 1: `native-from-scratch` (Standard library mastery, native HTTP server/tests)
- [x] Skill 2: `rigorous-code-audit` (Static analysis, linting, anti-pattern checks)

---

## 5. Phased Roadmap (Next Stages)

- **Phase 2**: Polyglot Native Language Blueprints (TypeScript/Node.js, Modern Python 3.12+, Idiomatic Go 1.22+, Systems Rust & C++).
- **Phase 3**: Enterprise Architecture & Systems Design (Hexagonal / Clean Architecture, Event-Driven State Machines, Resilient Retry & Circuit Breakers).
- **Phase 4**: Automated Testing, Mutation, & CI/CD Verification Guardrails (Property-Based Testing, Fuzz Testing, Static AST Linters).
