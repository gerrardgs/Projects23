# GEMINI Agent Guidelines & Operational Directives

This project adheres to the **Universal Clean Native Agent Specification (UCNA-Spec)**.

For full system rules, architectural invariants, clean coding disciplines, and anti-hallucination protocols, refer to and strictly enforce:
- [AGENTS.md](file:///Users/sinitygs/Projects23/AGENTS.md)
- [.agents/rules/](file:///Users/sinitygs/Projects23/.agents/rules/)
- [.agents/skills/](file:///Users/sinitygs/Projects23/.agents/skills/)

## Core Gemini Behavioral Requirements:
1. **Always-On Clean Native Standards**: Prioritize standard libraries, zero speculative dependencies, complete implementations (no TODO/ellipsis placeholders), and explicit type safety.
2. **Deterministic Anti-Hallucination**: Verify all API methods, package names, and CLI flags prior to execution.
3. **Structured & Audited Execution**: Formulate sound architectural foundations, audit changes against edge cases, and ensure deterministic tests pass.
