---
title: Rulebook Index & Execution Precedence
description: Catalog, trigger mechanics, and hierarchy for Universal Clean Native Agent Specification rules.
version: 1.0.0
---

# Universal Agent Rules Catalog (UCNA-Spec)

This directory defines the operational rules, quality constraints, and architectural standards enforced across all AI models and agent runtimes.

## Rule Index & Execution Map

| ID | Rule File | Scope | Primary Invariant |
| :--- | :--- | :--- | :--- |
| **R-01** | [01-core-philosophy.md](file:///.agents/rules/01-core-philosophy.md) | Universal | Native-first design, zero speculative bloat, 100% complete implementation. |
| **R-02** | [02-clean-code-invariants.md](file:///.agents/rules/02-clean-code-invariants.md) | Universal | Sound type safety, pure domain logic, explicit naming, cyclomatic complexity $\le 10$. |
| **R-03** | [03-anti-hallucination-verification.md](file:///.agents/rules/03-anti-hallucination-verification.md) | Universal | 5-step verification protocol: zero imaginary APIs, verified versions, compiler checks. |
| **R-04** | [04-native-standard-first.md](file:///.agents/rules/04-native-standard-first.md) | Polyglot | Standard library prioritization across TS, Python, Go, Rust, C++. Dependency elimination. |
| **R-05** | [05-defensive-error-handling.md](file:///.agents/rules/05-defensive-error-handling.md) | Universal | Explicit typed errors, Result/Option patterns, boundary invariants, structured telemetry. |

## Precedence & Conflicts
1. **Security & Data Integrity** takes precedence over all other considerations.
2. **Correctness & Type Safety** overrides brevity or speed of generation.
3. **Native Standard Library** solutions override third-party library recommendations.
4. **Implementation Completeness** overrides convenience (never use placeholders).
