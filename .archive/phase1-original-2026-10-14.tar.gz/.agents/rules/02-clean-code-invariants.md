---
title: Clean Code Invariants & Quality Standards
rule_id: R-02
target_models: ["all"]
target_languages: ["all"]
---

# R-02: Clean Code Invariants & Quality Standards

Clean code is not an aesthetic preference; it is a mathematical discipline of minimizing cognitive load, preventing state corruption, and ensuring deterministic execution.

---

## 1. Type Invariants & Zero-Bypass Rule

1. **No Type Bypasses**:
   - TypeScript: Never use `any`. Use `unknown` with runtime type narrowing (type guards, zod, or native validators). Do not use `@ts-ignore` or `@ts-nocheck` without explicit user permission and inline justification.
   - Python: Always supply comprehensive type hints (`typing` module / Python 3.12+ syntax `type`, `Sequence`, `Mapping`). Ensure `mypy --strict` or `pyright` passes cleanly.
   - Go: Never abuse `interface{}` / `any` for convenience. Use explicit interfaces or Go generics with clear type constraints (`comparable`, `constraints.Ordered`).
   - Rust: Strictly avoid uncontrolled `unsafe` blocks. Rely on the borrow checker, RAII, and standard pointer types.

2. **Discriminated Unions / Algebraic Data Types**:
   Model state machines using sum types / discriminated unions rather than boolean flag combinations (prevent invalid states from being representable in the type system).

```typescript
// BAD: Impossible states can be represented
type AsyncState<T> = {
  isLoading: boolean;
  isError: boolean;
  error?: Error;
  data?: T;
}; // Bug: isLoading=true and isError=true and data=T can coexist!

// GOOD: Discriminated union enforces mathematical validity
type AsyncState<T> =
  | { readonly status: 'idle' }
  | { readonly status: 'loading' }
  | { readonly status: 'success'; readonly data: T }
  | { readonly status: 'error'; readonly error: Readonly<Error> };
```

---

## 2. Naming Discipline & Domain Ubiquity

1. **Intention-Revealing Identifiers**:
   - Variables and constants must describe *what they hold*, not how they are implemented.
   - Functions and methods must begin with an active verb (`calculateTax`, `verifyChecksum`, `parseRequestHeader`).
   - Boolean variables must be prefixed with `is`, `has`, `should`, or `can` (`isValid`, `hasExpired`, `canRetry`).
2. **Eliminate Cryptic Abbreviations**:
   - Avoid: `ctx`, `req`, `res`, `usr`, `t`, `val`, `fn`.
   - Prefer: `context`, `request`, `response`, `user`, `timestamp`, `value`, `handler`.
   - Exception: Standard loop indices `i`, `j`, `k` in short, local, arithmetic loops ($\le 5$ lines).

---

## 3. Separation of Domain Logic and Side Effects (Functional Core, Imperative Shell)

1. **Domain Core (Pure)**:
   - Business calculations, validation, transformations, and state transitions must be pure functions.
   - Pure functions take inputs and return outputs with zero network calls, disk I/O, or hidden mutable state.
   - Highly testable without mocking frameworks.

2. **Shell (Imperative I/O)**:
   - Handles network requests, database transactions, file system interactions, system clocks, and telemetry.
   - Orchestrates calls to the pure domain core.

```mermaid
graph TD
    subgraph Imperative Shell
        HTTP[HTTP Request / CLI / Queue] --> ShellController[Shell Controller / Handler]
        ShellController --> DB[(Database / External API)]
    end
    subgraph Pure Functional Core
        ShellController --> DomainModel[Domain Rules & Entities]
        DomainModel --> StateTransition[Pure State Transition / Calc]
        StateTransition --> DomainModel
    end
```

---

## 4. Immutability by Default

- In TypeScript: Use `readonly` arrays, `Readonly<T>`, and `as const` assertions.
- In Python: Use `@dataclass(frozen=True)` or `NamedTuple` for domain transfers and value objects.
- In Go: Avoid returning mutable pointers to internal state slices/maps; return copies or immutable interfaces.
- In Rust: Keep variables immutable (`let`) by default; use `mut` strictly when in-place mutation provides measurable performance gains.
