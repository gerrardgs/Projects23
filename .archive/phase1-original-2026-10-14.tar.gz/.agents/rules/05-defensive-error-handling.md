---
title: Defensive Error Handling & Invariant Enforcement
rule_id: R-05
target_models: ["all"]
target_languages: ["all"]
---

# R-05: Defensive Error Handling & Invariant Enforcement

Errors are not exceptional occurrences; they are expected computational outcomes in distributed systems, user interactions, and I/O boundaries. They must be modeled as explicit, typed, and traceable domain concepts.

---

## 1. The Result / Either Pattern for Predictable Failure

Avoid throwing uncontrolled exceptions across domain boundaries. Return explicit `Result<T, E>` types so calling code is forced to handle failure paths at compile time.

### Lightweight Native Result Type (TypeScript):
```typescript
export type Result<T, E> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: E };

export const Result = {
  ok<T>(value: T): Result<T, never> {
    return { ok: true, value };
  },
  err<E>(error: E): Result<never, E> {
    return { ok: false, error };
  },
  fromThrowable<T, E = Error>(
    fn: () => T,
    mapError: (thrown: unknown) => E = (e) => (e instanceof Error ? (e as E) : (new Error(String(e)) as unknown as E))
  ): Result<T, E> {
    try {
      return Result.ok(fn());
    } catch (e) {
      return Result.err(mapError(e));
    }
  },
  async fromPromise<T, E = Error>(
    promise: Promise<T>,
    mapError: (thrown: unknown) => E = (e) => (e instanceof Error ? (e as E) : (new Error(String(e)) as unknown as E))
  ): Promise<Result<T, E>> {
    try {
      return Result.ok(await promise);
    } catch (e) {
      return Result.err(mapError(e));
    }
  },
} as const;
```

---

## 2. Boundary Validation Invariants (Fail-Fast)

1. **Verify at the Perimeter, Trust Within**:
   - Validate every external input (HTTP request body, CLI argument, query parameter, environment variable, message queue payload) immediately at the ingestion boundary.
   - Once validated, transform the input into an immutable, strongly-typed internal domain entity. Do not re-validate internal trusted code repeatedly.
2. **Never Swallow Errors**:
   - NEVER write `catch (e) {}` or `catch (err) { console.log(err); }` without re-throwing or converting to a domain failure value.
   - If an error cannot be recovered from, propagate it with causal context (e.g. `new Error("Failed to process transaction", { cause: originalError })`).

---

## 3. Structured Diagnostic Telemetry

- Log with structured key-value pairs (JSON format or structured logger) rather than string interpolation.
- Include correlation identifiers (`traceId`, `requestId`, `userId`, `operation`).
- Never leak sensitive user data (passwords, tokens, credit cards, PII) in error messages or logs.
