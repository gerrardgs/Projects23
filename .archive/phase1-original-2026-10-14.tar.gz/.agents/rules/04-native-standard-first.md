---
title: Native-Standard-First Paradigm & Dependency Elimination
rule_id: R-04
target_models: ["all"]
target_languages: ["typescript", "javascript", "python", "go", "rust"]
---

# R-04: Native-Standard-First Paradigm & Dependency Elimination

This rule guides agents to replace bloatware dependencies with modern, elegant standard library implementations.

---

## 1. Modern TypeScript & Node.js Native Replacements

| Legacy / Bloated Package | Native Modern Standard (Node 20+) | Native Code Pattern |
| :--- | :--- | :--- |
| `axios` / `node-fetch` | Native `fetch` + `AbortSignal` | `await fetch(url, { signal: AbortSignal.timeout(5000) })` |
| `uuid` | `crypto.randomUUID()` | `crypto.randomUUID()` (global in Node 16.7+ & browsers) |
| `lodash.cloneDeep` | `structuredClone()` | `const copy = structuredClone(original);` |
| `lodash.flatten` | `Array.prototype.flat()` | `items.flat(Infinity)` |
| `lodash.uniq` | `Set` | `Array.from(new Set(items))` |
| `rimraf` / `mkdirp` | `node:fs/promises` | `fs.rm(path, { recursive: true, force: true })` |
| `dotenv` | Node `--env-file` / native parser | `process.loadEnvFile()` or native parse regex |
| `querystring` | `URLSearchParams` | `new URLSearchParams({ query: 'val' }).toString()` |
| `chalk` (basic colors) | `node:util` `styleText` (Node 20.12+) | `util.styleText('green', 'Success!')` |

### Concrete Native Example: Production-Ready Native HTTP Client
```typescript
export interface HttpResponse<T> {
  readonly status: number;
  readonly ok: boolean;
  readonly data: T;
  readonly headers: Headers;
}

export async function requestJson<T>(
  url: string | URL,
  options: Readonly<{
    method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
    body?: unknown;
    headers?: Record<string, string>;
    timeoutMs?: number;
  }> = {}
): Promise<HttpResponse<T>> {
  const { method = 'GET', body, headers = {}, timeoutMs = 10000 } = options;
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        ...headers,
      },
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    });

    const data: T = await response.json();
    return {
      status: response.status,
      ok: response.ok,
      data,
      headers: response.headers,
    };
  } finally {
    clearTimeout(timeoutId);
  }
}
```

---

## 2. Python 3.11+ Native Standard Library Power

| Unnecessary Dependency | Modern Python Standard Replacement |
| :--- | :--- |
| `python-dateutil` | `datetime.datetime.fromisoformat()` |
| `attrs` (basic) | `@dataclasses.dataclass(slots=True, frozen=True)` |
| `pathlib2` / `os.path` | `pathlib.Path` |
| `mock` | `unittest.mock` |
| `simplejson` | `json` |
| `typing_extensions` (if on 3.12+) | Native `type` alias, `Self`, generics syntax PEP 695 |

---

## 3. Go (1.22+) Standard Library Power

- **Routing**: Use `net/http.ServeMux` with method routing and wildcards (`mux.HandleFunc("GET /users/{id}", handleGetUser)`). Avoid introducing heavy external routers unless enterprise middleware chains strictly mandate it.
- **Structured Logging**: Use `log/slog` (standard in Go 1.21+). Do NOT import `logrus` or third-party loggers for basic structured logging.
- **Concurrency**: Use `sync.WaitGroup`, `sync.OnceValue`, and `golang.org/x/sync/errgroup` with standard context cancellation.
