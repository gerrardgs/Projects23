---
title: Core Philosophy & Native Architectural Axioms
rule_id: R-01
target_models: ["all"]
target_languages: ["all"]
---

# R-01: Core Philosophy & Native Architectural Axioms

This rule defines the foundational mindset every AI agent must adopt when generating, modifying, or auditing code.

---

## 1. Axiom of Native-First Engineering

Native-first engineering means solving problems using the language runtime's core language features and official standard library before considering external packages.

### Why External Dependencies Must Be Earned:
- Every external dependency introduces a supply-chain attack vector, dependency management overhead, security audit burdens, potential breaking updates, and bundle/binary bloat.
- Modern runtime environments (Node.js 20+, Python 3.11+, Go 1.22+, Rust 2021+) provide rich, battle-tested standard libraries that obviate 80% of legacy third-party utility packages.

### The Dependency Decision Matrix:
Before introducing any external dependency, the agent must pass this strict checklist:
1. **Can this be implemented natively in $\le 50$ lines of clean, well-tested code?** If YES $\rightarrow$ write it natively.
2. **Is this a utility that duplicates runtime standard libraries (e.g., `axios` vs `fetch`, `uuid` vs `crypto.randomUUID`, `lodash` vs modern Array/Object methods)?** If YES $\rightarrow$ use the standard library.
3. **Does the problem require heavy algorithmic domains (e.g., cryptographic verification primitives, full relational database drivers, complex parsers like AST/WASM)?** If YES $\rightarrow$ select the single most audited, zero-bloat, widely accepted industry standard package.

---

## 2. Axiom of Implementation Completeness (Anti-Lazy Invariant)

AI agents frequently degrade user trust by producing partial answers, stubs, or placeholder code. This behavior is strictly prohibited.

### Prohibited Patterns:
```typescript
// BAD: Unacceptable agent shortcuts
function processPayment(payload: PaymentPayload): Promise<PaymentResult> {
  // TODO: validate payload
  // ... implement payment gateway call
  return Promise.resolve({ success: true } as any);
}
```

### Mandatory Complete Pattern:
```typescript
// GOOD: Production-ready completeness
export async function processPayment(
  payload: Readonly<PaymentPayload>,
  gateway: PaymentGatewayClient
): Promise<Result<PaymentResult, PaymentError>> {
  const validation = validatePaymentPayload(payload);
  if (!validation.ok) {
    return Result.err(new PaymentValidationError(validation.errors));
  }

  try {
    const response = await gateway.charge({
      amount: payload.amountInCents,
      currency: payload.currency,
      token: payload.paymentToken,
      idempotencyKey: payload.idempotencyKey,
    });
    return Result.ok({
      transactionId: response.transactionId,
      status: response.status,
      timestamp: new Date(response.timestampMs),
    });
  } catch (error: unknown) {
    return Result.err(PaymentError.fromUnknown(error, payload.idempotencyKey));
  }
}
```

---

## 3. Axiom of Cognitive Simplicity (KISS & YAGNI)

1. **Avoid Premature Generalized Frameworks**: Write concrete code for the immediate problem first. Do not introduce 5 layers of abstract generic interfaces for a feature that only has one implementation today.
2. **Single Level of Abstraction Principle (SLAP)**: Keep the statements within a single function at the same level of conceptual abstraction. Do not mix high-level business orchestration with low-level bit shifting or string buffer allocation.
3. **Flat Over Deeply Nested**: Keep indentation depth $\le 3$. Use early returns (guard clauses) to eliminate nested `if/else` ladders.
