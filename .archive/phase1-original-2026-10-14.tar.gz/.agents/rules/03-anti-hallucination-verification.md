---
title: Anti-Hallucination Protocol & Verification Discipline
rule_id: R-03
target_models: ["all"]
target_languages: ["all"]
---

# R-03: Anti-Hallucination Protocol & Verification Discipline

AI models frequently experience hallucinations: inventing non-existent package methods, generating deprecated APIs, assuming incorrect file paths, or fabricating CLI arguments. This rule provides a mandatory, multi-step deterministic verification process to eliminate hallucinations completely.

---

## 1. The 5-Step Anti-Hallucination Protocol

Before delivering any code, command, or architectural change, the agent must execute this 5-step cognitive audit:

```mermaid
graph TD
    S1[1. Ground Reality] --> S2[2. Verify Signatures]
    S2 --> S3[3. Check Deprecations]
    S3 --> S4[4. Syntax & Static Analysis]
    S4 --> S5[5. Runtime & Boundary Audit]
```

### Step 1: Ground Reality in the Active Workspace
- Never guess the structure of the workspace. Always inspect project configuration files:
  - Node/JS: `package.json`, `tsconfig.json`
  - Python: `pyproject.toml`, `requirements.txt`, `setup.cfg`
  - Go: `go.mod`, `go.sum`
  - Rust: `Cargo.toml`, `Cargo.lock`
- Confirm which major runtime version is in use (e.g. Node 18 vs Node 20 vs Node 22; Python 3.9 vs 3.12).

### Step 2: Verify Exact API Signatures
- When using external or internal libraries, verify that the function, class, or method actually exists in that exact version.
- Inspect installed type definitions (`node_modules/@types/`, `venv/lib/...`, Go doc, or `cargo doc`) or read the relevant source file before making assumptions.
- If an API method has multiple overloads or optional parameter bags, verify the exact object structure.

### Step 3: Check Deprecations & Breaking Changes
- Never write code using deprecated features (e.g., Node's `new Buffer()`, Python's `asyncio.get_event_loop()` without active loop checks, React's deprecated lifecycle hooks).
- Ensure modern replacements are used (e.g., `Buffer.from()`, `asyncio.new_event_loop()`).

### Step 4: Syntax & Static Analysis Verification
- Ensure code parses cleanly.
- If a compiler or linter is available in the environment (`tsc`, `mypy`, `ruff`, `eslint`, `golangci-lint`, `cargo check`), run or simulate the exact static analysis to guarantee zero errors.

### Step 5: Runtime & Boundary Audit
- Audit zero-values, `null`, `undefined`, empty collections, network disconnects, and timeout states.
- Ensure all resources (file descriptors, sockets, database pool handles) are wrapped in deterministic cleanup blocks (`try/finally`, `using`, Python `with`, Go `defer`, Rust RAII `Drop`).

---

## 2. Hard Anti-Hallucination Rules for Code Generation

1. **No Phantom Packages**: Never import an npm/pip/go/cargo package unless it is already declared in the project's dependency manifest or the user explicitly requested its installation.
2. **No Phantom CLI Flags**: Never guess command-line flags for system tools (`docker`, `kubectl`, `git`, `ffmpeg`, `tar`). Verify flags with `--help` or man pages before running or recommending them.
3. **No Phantom Environment Variables**: Always declare required environment variables in a documented configuration schema or `.env.example` with fallback handling or clear error messages on missing secrets.
