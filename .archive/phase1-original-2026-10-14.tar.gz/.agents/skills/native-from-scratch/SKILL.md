---
name: native-from-scratch
description: >-
  Build robust, production-grade applications, modules, and utilities native from scratch
  using standard runtime libraries without external dependency bloat. Use when creating new
  services, refactoring legacy dependencies, or implementing core algorithmic and data structures.
---

# Native-From-Scratch Engineering Skill

This skill guides an AI agent through designing, structuring, and implementing production-ready software systems using strictly native standard libraries and zero-bloat patterns.

---

## 1. When to Activate This Skill

- Building a new microservice, CLI tool, or web API from the ground up.
- Refactoring bloated codebases burdened with unnecessary npm packages, pip packages, or transitive dependencies.
- Writing high-performance, low-latency modules where runtime overhead and bundle size matter.
- Implementing custom caching, state machines, protocol parsers, or HTTP clients.

---

## 2. Core Execution Protocol

When instructed to write a system or component "native from scratch", follow these 5 phases:

### Phase 1: Standard Library Assessment
1. Determine the runtime version (e.g., Node 20+, Python 3.11+, Go 1.22+, Rust 2021+).
2. Enumerate which native modules solve the problem:
   - **Networking & HTTP**: `fetch`, `node:http`, `urllib.request`, `net/http`, `std::net`.
   - **File System & Paths**: `node:fs/promises`, `pathlib.Path`, `os`, `io`, `std::fs`.
   - **Cryptography & Randomness**: `node:crypto` (`randomUUID`, `createHash`, `timingSafeEqual`), `hashlib`, `secrets`, `crypto/*`.
   - **Concurrency & Async**: `AbortController`, `asyncio`, `sync/errgroup`, `tokio` (if in async Rust).
   - **Data Structures**: Native Map, Set, TypedArrays, `collections.deque`, `heapq`, slices, maps.

### Phase 2: Domain Boundary Definition
- Create clean interfaces/contracts separating pure domain logic from I/O mechanisms.
- Define explicit types, invariants, and mathematical domain models.

### Phase 3: Zero-Bloat Implementation
- Write complete, robust, type-checked implementations.
- No partial stubs, no ellipsis, no unresolved TODOs.
- Enforce memory safety, explicit error returns (`Result<T, E>`), and resource cleanup (`defer`, `finally`, `with`).

### Phase 4: Deterministic Native Unit Testing
- Test using native test runners without pulling in heavy external test frameworks:
  - Node.js: `node:test` + `node:assert/strict` (built into Node 18+)
  - Python: `unittest` (or standard `pytest` if already configured in project)
  - Go: Standard `testing` package with table-driven tests
  - Rust: Built-in `#[cfg(test)]` and `cargo test`

---

## 3. Concrete Native Blueprints

### Blueprint: Node.js Native Microservice with `node:http` & `node:test`

```typescript
// server.ts - 100% Native Production HTTP Service
import http from 'node:http';
import { randomUUID } from 'node:crypto';

export interface User {
  readonly id: string;
  readonly name: string;
  readonly email: string;
}

export class InMemoryUserStore {
  private readonly users = new Map<string, User>();

  create(name: string, email: string): User {
    const user: User = { id: randomUUID(), name, email };
    this.users.set(user.id, user);
    return user;
  }

  get(id: string): User | undefined {
    return this.users.get(id);
  }
}

export function createServer(store: InMemoryUserStore): http.Server {
  return http.createServer(async (req, res) => {
    const { method, url } = req;
    res.setHeader('Content-Type', 'application/json');

    if (method === 'GET' && url?.startsWith('/users/')) {
      const id = url.slice('/users/'.length);
      const user = store.get(id);
      if (!user) {
        res.writeHead(404);
        res.end(JSON.stringify({ error: 'User not found' }));
        return;
      }
      res.writeHead(200);
      res.end(JSON.stringify(user));
      return;
    }

    if (method === 'POST' && url === '/users') {
      let body = '';
      req.on('data', (chunk) => { body += chunk; });
      req.on('end', () => {
        try {
          const parsed = JSON.parse(body);
          if (!parsed.name || !parsed.email) {
            res.writeHead(400);
            res.end(JSON.stringify({ error: 'Missing required fields: name, email' }));
            return;
          }
          const user = store.create(parsed.name, parsed.email);
          res.writeHead(201);
          res.end(JSON.stringify(user));
        } catch {
          res.writeHead(400);
          res.end(JSON.stringify({ error: 'Invalid JSON payload' }));
        }
      });
      return;
    }

    res.writeHead(404);
    res.end(JSON.stringify({ error: 'Route not found' }));
  });
}
```

```typescript
// server.test.ts - 100% Native Test Runner (node:test)
import test from 'node:test';
import assert from 'node:assert/strict';
import { InMemoryUserStore, createServer } from './server.js';
import type { AddressInfo } from 'node:net';

test('Native HTTP User Service Flow', async (t) => {
  const store = new InMemoryUserStore();
  const server = createServer(store);

  await new Promise<void>((resolve) => server.listen(0, resolve));
  const port = (server.address() as AddressInfo).port;
  const baseUrl = `http://127.0.0.1:${port}`;

  t.after(() => server.close());

  await t.test('creates user and retrieves by ID', async () => {
    const createRes = await fetch(`${baseUrl}/users`, {
      method: 'POST',
      body: JSON.stringify({ name: 'Ada Lovelace', email: 'ada@example.com' }),
    });
    assert.equal(createRes.status, 201);
    const created = await createRes.json();
    assert.equal(created.name, 'Ada Lovelace');
    assert.ok(created.id);

    const getRes = await fetch(`${baseUrl}/users/${created.id}`);
    assert.equal(getRes.status, 200);
    const fetched = await getRes.json();
    assert.deepEqual(fetched, created);
  });
});
```
