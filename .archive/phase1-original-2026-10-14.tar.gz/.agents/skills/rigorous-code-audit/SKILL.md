---
name: rigorous-code-audit
description: >-
  Conduct comprehensive architectural, security, correctness, and clean-code audits on codebases.
  Use when reviewing pull requests, evaluating existing code before refactoring, diagnosing subtle
  production bugs, or performing pre-flight anti-hallucination and static analysis checks.
---

# Rigorous Code Audit Skill

This skill outlines a systematic, zero-compromise auditing process used by principal software architects to evaluate codebases for correctness, security, architectural integrity, and clean-code compliance.

---

## 1. Audit Checkpoints Matrix

| Domain | Key Inspection Vector | Passing Standard |
| :--- | :--- | :--- |
| **Type Safety** | No `any`, `@ts-ignore`, unchecked casts | 100% strict compiler pass |
| **Completeness** | No `TODO`, `...`, stubbed returns | Zero placeholders, complete implementations |
| **Architecture** | Hexagonal separation, low coupling | Pure domain logic isolated from side effects |
| **Error Handling** | Typed errors, `Result<T, E>`, no empty catches | All rejection paths handled with context |
| **Resource Safety** | Streams, sockets, memory leaks | Deterministic disposal (`finally`, `defer`, `Drop`) |
| **Complexity** | Cyclomatic complexity & nesting depth | Cyclomatic complexity $\le 10$, Nesting $\le 3$ |
| **Security** | OWASP Top 10, injection, timing attacks | Parameterized queries, constant-time compare |

---

## 2. Step-by-Step Audit Workflow

```mermaid
graph TD
    A[Step 1: Surface Scan] --> B[Step 2: Typecheck & Compile]
    B --> C[Step 3: Anti-Pattern & Invariant Audit]
    C --> D[Step 4: Concurrency & Resource Audit]
    D --> E[Step 5: Test Coverage & Mutation Check]
```

### Step 1: Surface & Placeholder Scan
Run pattern searches across changed files for common agent laziness artifacts:
- Grep for `TODO`, `FIXME`, `HACK`, `...`, `pass`, `NotImplementedError`.
- Ensure all exported functions have complete parameter and return signatures.

### Step 2: Typecheck & Static Analysis Execution
Execute the workspace's native typechecker:
- **TypeScript**: `npx tsc --noEmit --strict`
- **Python**: `python3 -m mypy --strict .` or `ruff check .`
- **Go**: `go vet ./...` and `golangci-lint run`
- **Rust**: `cargo clippy --all-targets -- -D warnings`

### Step 3: Anti-Pattern & Invariant Audit
1. **Unchecked Null/Undefined**: Check if optional properties are accessed without null-coalescing (`?.`) or proper guards.
2. **Side Effects in Domain Logic**: Ensure domain calculation functions do not perform network or disk I/O.
3. **Primitive Obsession**: Replace raw strings with branded types or value objects (e.g., `UserId` instead of raw `string`).

### Step 4: Concurrency & Resource Audit
1. Check for unhandled asynchronous errors (unhandled promise rejections, unawaited promises).
2. Check for race conditions in shared mutable memory (ensure proper locks, channels, or atomic operations are used).
3. Verify that file handles, network listeners, and timers are cleared during error conditions or teardown.

### Step 5: Test Coverage & Verification
1. Ensure both happy path and edge cases (empty strings, zero, negative numbers, high concurrency, network dropouts) have unit tests.
2. Run tests to confirm zero regressions.
